﻿
namespace CST_227_Milestone_Project
{
    interface IPlayable
    {
        void PlayGame();
    }
}
